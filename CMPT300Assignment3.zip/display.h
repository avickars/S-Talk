#ifndef _DISPLAY_H_
#define _DISPLAY_H_

extern pthread_t displayThread;

void displayInit();

void displayDestructor();

#endif